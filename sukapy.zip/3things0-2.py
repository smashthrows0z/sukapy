import subprocess
import os

# Define the text file containing the file number
file_number_file = 'sukanumber.txt'

# Initialize a list to store the names of deleted files
deleted_files = []

# Read the current file number from the text file
try:
    with open(file_number_file, 'r') as file:
        file_number = int(file.read())
except FileNotFoundError:
    # If the file doesn't exist, start from 1
    file_number = 1

# Run the first command to create 3thingsXX.mp4
input_file = 'snippet_list.txt'
output_file = f'3things{file_number}.mp4'
command1 = f'ffmpeg -f concat -safe 0 -i {input_file} -c:v h264_nvenc -an {output_file}'
subprocess.call(command1, shell=True)

# Run the second command to create outputsukaXX.mp4
input_file = f'3things{file_number}.mp4'
output_file = f'/content/outputsuka{file_number}.mp4'
command2 = f'ffmpeg -i {input_file} -i outputc_10x.m4a -c:v copy -map 0:v -map 1:a -shortest -y {output_file}'
subprocess.call(command2, shell=True)

# Increment the file number and update it in the text file
file_number += 1
with open(file_number_file, 'w') as file:
    file.write(str(file_number))

# Read the list of files from snippet_list.txt and extract the actual file names
with open('snippet_list.txt', 'r') as file:
    for line in file:
        if line.startswith("file '") and line.endswith("'\n"):
            filename = line[len("file '"): -2]
            deleted_files.append(filename)

# Delete the files referenced in snippet_list.txt
for filename in deleted_files:
    try:
        os.remove(filename)
    except OSError as e:
        print(f"Error deleting {filename}: {e}")

# Print the list of deleted files
print("Deleted files:")
for deleted_file in deleted_files:
    print(deleted_file)
