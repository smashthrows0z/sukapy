import subprocess
import os

# Define the text file containing the file number
file_number_file = 'sukanumber.txt'

# Initialize a list to store the names of deleted files
deleted_files = []

# Read the current file number from the text file
try:
    with open(file_number_file, 'r') as file:
        file_number = int(file.read())
except FileNotFoundError:
    # If the file doesn't exist, start from 1
    file_number = 1

# Run the first command to create 3thingsXX.mp4
input_file = 'snippet_list.txt'
output_file = f'3things{file_number}.mp4'
command1 = f'ffmpeg -f concat -safe 0 -i {input_file} -c:v h264_nvenc -an {output_file}'
subprocess.call(command1, shell=True)

# Run the second command to create outputsukaXX.mp4
input_file = f'3things{file_number}.mp4'
output_file = f'/content/outputsuka{file_number}.mp4'
command2 = f'ffmpeg -i {input_file} -i outputc_10x.m4a -c:v copy -map 0:v -map 1:a -shortest -y {output_file}'
subprocess.call(command2, shell=True)

# Increment the file number and update it in the text file
file_number += 1
with open(file_number_file, 'w') as file:
    file.write(str(file_number))

