def read_text_file(file_name):
    with open(file_name, 'r') as file:
        lines = file.readlines()
    return [line.strip() for line in lines]

def interleave_lists(lists):
    max_length = max(len(lst) for lst in lists)
    result = []
    for i in range(max_length):
        for lst in lists:
            if i < len(lst):
                result.append(lst[i])
    return result

# Read the file containing file names
with open('/content/2mix.txt', 'r') as file:
    file_names = [line.strip() for line in file]

# Modify file names to add "snippet_list.txt"
file_names_with_snippet = [file_name + "snippet_list.txt" for file_name in file_names]

# Read the contents of each file into separate lists
lists = [read_text_file(file) for file in file_names_with_snippet]

# Interleave the lists
interleaved_list = interleave_lists(lists)

# Write the result to an output file or print it
with open('snippet_list.txt', 'w') as file:
    for item in interleaved_list:
        file.write(f"{item}\n")

with open('snippet_list.txt', 'r') as file:
    contents = file.read()

print(contents)