import subprocess
import random
import sys
import os
import string
import argparse

# ... (your script with modifications to accept input_video_names)

# Read the list of input video names from a text file
input_video_names = []

file_path = '/content/2mix.txt'

with open(file_path, 'r') as file:
    for line in file:
        video_name = line.strip()
        input_video_names.append(video_name)

# Process each video in the list
for video_name in input_video_names:
    video_name_with_extension = f"{video_name}.mp4"
    command = f"python vbgm.py {video_name_with_extension} 0 d 4 1 k"
    os.system(command)
